hw3: Scene in 3D

Alexis McBeain
CSCI 4229/5229 Fall 2020

Time took to complete: 2 days

UPDATE: Unsure of what was being seen that needed to be addressed but I fixed the buildings into 
more of a cube shape making the buildings look more solid. That, in turn, also led to me
chaning some of the shape transformations. 

Key Binds:

	S  	 	Turn Window lights off
	W 	 	Turn Window lights on
	ARROW KEYS  	Axis movement/Change view angle
	SPACEBAR 	Reset view angle 
	ESC 		Exit
